# ceia.fácil — prompts de imagem (IA)

Como usar: cole cada prompt na ferramenta de IA, gere em 4:3 e salve com o **nome do arquivo** indicado.
Confira se a foto bate com a receita (ingredientes visíveis certos). Descarte imagens com texto, mãos ou marcas.

Estilo fixo (já incluído em cada prompt):

> Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels

## 01. Peru assado tradicional (salgado)
Arquivo: `peru-assado-tradicional.png`

```
Peru assado tradicional (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: peru, alho, cebola, vinho branco seco, suco de laranja. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 02. Chester assado (salgado)
Arquivo: `chester-assado.png`

```
Chester assado (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: chester, suco de laranja, manteiga, alho, cebola. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 03. Pernil suíno assado (salgado)
Arquivo: `pernil-suino-assado.png`

```
Pernil suíno assado (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: pernil, alho, cebola, vinho branco, suco de limão. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 04. Lombo suíno ao molho de laranja (salgado)
Arquivo: `lombo-suino-ao-molho-de-laranja.png`

```
Lombo suíno ao molho de laranja (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: lombo, alho, suco de laranja, mostarda, mel. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 05. Tender natalino com abacaxi (salgado)
Arquivo: `tender-natalino-com-abacaxi.png`

```
Tender natalino com abacaxi (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: tender, abacaxi, suco de laranja, mel, mostarda. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 06. Frango assado com batatas (salgado)
Arquivo: `frango-assado-com-batatas.png`

```
Frango assado com batatas (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: frango, alho, limão, manteiga, páprica doce. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 07. Frango recheado com farofa (salgado)
Arquivo: `frango-recheado-com-farofa.png`

```
Frango recheado com farofa (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: frango, alho, limão, manteiga, sal. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 08. Bacalhau ao forno (salgado)
Arquivo: `bacalhau-ao-forno.png`

```
Bacalhau ao forno (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: bacalhau dessalgado, batata, cebola, tomate, alho. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 09. Peixe assado com ervas e limão (salgado)
Arquivo: `peixe-assado-com-ervas-e-limao.png`

```
Peixe assado com ervas e limão (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: peixe inteiro, limão, alho, azeite, sal. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 10. Carne assada ao molho madeira (salgado)
Arquivo: `carne-assada-ao-molho-madeira.png`

```
Carne assada ao molho madeira (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: carne, cebola, alho, vinho tinto seco, caldo sem excesso de sal. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 11. Costela suína assada (salgado)
Arquivo: `costela-suina-assada.png`

```
Costela suína assada (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: costela, alho, páprica, açúcar mascavo, mostarda. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 12. Costela bovina assada (salgado)
Arquivo: `costela-bovina-assada.png`

```
Costela bovina assada (Brazilian Christmas dish), presented on a large platter, ready to serve, visible ingredients: costela, sal grosso, alho, cebola, pimenta-do-reino. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 13. Arroz à grega (salgado)
Arquivo: `arroz-a-grega.png`

```
Arroz à grega (Brazilian Christmas dish), in a serving bowl, visible ingredients: arroz, água, cebola, alho, cenoura. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 14. Arroz natalino com castanhas (salgado)
Arquivo: `arroz-natalino-com-castanhas.png`

```
Arroz natalino com castanhas (Brazilian Christmas dish), in a serving bowl, visible ingredients: arroz, água, cebola, alho, castanha-de-caju. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 15. Arroz com brócolis (salgado)
Arquivo: `arroz-com-brocolis.png`

```
Arroz com brócolis (Brazilian Christmas dish), in a serving bowl, visible ingredients: arroz, água, brócolis, alho, cebola. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 16. Farofa de bacon e cebola (salgado)
Arquivo: `farofa-de-bacon-e-cebola.png`

```
Farofa de bacon e cebola (Brazilian Christmas dish), in a serving bowl, visible ingredients: farinha de mandioca, bacon, cebola, manteiga, alho. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 17. Farofa de banana (salgado)
Arquivo: `farofa-de-banana.png`

```
Farofa de banana (Brazilian Christmas dish), in a serving bowl, visible ingredients: farinha, banana-da-terra, manteiga, cebola, alho. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 18. Farofa de calabresa com ovos (salgado)
Arquivo: `farofa-de-calabresa-com-ovos.png`

```
Farofa de calabresa com ovos (Brazilian Christmas dish), in a serving bowl, visible ingredients: farinha, calabresa, ovos, cebola, manteiga. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 19. Farofa natalina com frutas secas (salgado)
Arquivo: `farofa-natalina-com-frutas-secas.png`

```
Farofa natalina com frutas secas (Brazilian Christmas dish), in a serving bowl, visible ingredients: farinha, manteiga, cebola, damasco, uva-passa. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 20. Batata gratinada (salgado)
Arquivo: `batata-gratinada.png`

```
Batata gratinada (Brazilian Christmas dish), in a serving bowl, visible ingredients: batata, creme de leite, leite, queijo muçarela, parmesão. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 21. Purê de mandioquinha (salgado)
Arquivo: `pure-de-mandioquinha.png`

```
Purê de mandioquinha (Brazilian Christmas dish), in a serving bowl, visible ingredients: mandioquinha, leite, manteiga, creme de leite, sal. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 22. Salpicão de frango (salgado)
Arquivo: `salpicao-de-frango.png`

```
Salpicão de frango (Brazilian Christmas dish), in a glass serving bowl, visible ingredients: frango, cenoura, maçã, milho, ervilha. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 23. Maionese de batata (salgado)
Arquivo: `maionese-de-batata.png`

```
Maionese de batata (Brazilian Christmas dish), in a glass serving bowl, visible ingredients: batata, cenoura, ervilha, maionese, mostarda. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 24. Vinagrete tradicional (salgado)
Arquivo: `vinagrete-tradicional.png`

```
Vinagrete tradicional (Brazilian Christmas dish), in a glass serving bowl, visible ingredients: tomate, cebola, pimentão, vinagre, azeite. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 25. Salada tropical (salgado)
Arquivo: `salada-tropical.png`

```
Salada tropical (Brazilian Christmas dish), in a glass serving bowl, visible ingredients: alface, manga, abacaxi, cenoura, tomate-cereja. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 26. Salada de grão-de-bico (salgado)
Arquivo: `salada-de-grao-de-bico.png`

```
Salada de grão-de-bico (Brazilian Christmas dish), in a glass serving bowl, visible ingredients: grão-de-bico cozido, tomate, cebola roxa, pepino, azeite. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 27. Cuscuz paulista (salgado)
Arquivo: `cuscuz-paulista.png`

```
Cuscuz paulista (Brazilian Christmas dish), in a glass serving bowl, visible ingredients: farinha de milho flocada, sardinha, molho de tomate, água ou caldo, ervilha. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 28. Caponata de berinjela (salgado)
Arquivo: `caponata-de-berinjela.png`

```
Caponata de berinjela (Brazilian Christmas dish), in a glass serving bowl, visible ingredients: berinjela, pimentão, cebola, alho, azeite. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 29. Legumes assados (salgado)
Arquivo: `legumes-assados.png`

```
Legumes assados (Brazilian Christmas dish), on a wooden board, visible ingredients: abobrinha, cenoura, cebola, pimentão, batata. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 30. Torta fria de frango (salgado)
Arquivo: `torta-fria-de-frango.png`

```
Torta fria de frango (Brazilian Christmas dish), on a wooden board, visible ingredients: pão de forma, frango cozido desfiado, maionese, cenoura, milho. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 31. Empadão de frango (salgado)
Arquivo: `empadao-de-frango.png`

```
Empadão de frango (Brazilian Christmas dish), on a wooden board, visible ingredients: farinha, manteiga, ovo, água gelada, frango cozido. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 32. Quiche de alho-poró (salgado)
Arquivo: `quiche-de-alho-poro.png`

```
Quiche de alho-poró (Brazilian Christmas dish), on a wooden board, visible ingredients: farinha, manteiga, ovo, alho-poró, creme de leite. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 33. Bolinho de bacalhau (salgado)
Arquivo: `bolinho-de-bacalhau.png`

```
Bolinho de bacalhau (Brazilian Christmas dish), on a wooden board, visible ingredients: bacalhau dessalgado, batata, ovo, cebola, salsinha. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 34. Bruschetta de tomate (salgado)
Arquivo: `bruschetta-de-tomate.png`

```
Bruschetta de tomate (Brazilian Christmas dish), on a wooden board, visible ingredients: pão italiano, tomate, alho, azeite, manjericão. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 35. Patê de atum (salgado)
Arquivo: `pate-de-atum.png`

```
Patê de atum (Brazilian Christmas dish), on a wooden board, visible ingredients: atum drenado, maionese, cream cheese, limão, cebola. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 36. Pão recheado com queijo e ervas (salgado)
Arquivo: `pao-recheado-com-queijo-e-ervas.png`

```
Pão recheado com queijo e ervas (Brazilian Christmas dish), on a wooden board, visible ingredients: pão italiano, muçarela, requeijão, parmesão, manteiga. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 01. Pavê de chocolate (sobremesa)
Arquivo: `pave-de-chocolate.png`

```
Pavê de chocolate (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite, leite condensado, creme de leite, amido, chocolate em pó. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 02. Pavê de Bis (sobremesa)
Arquivo: `pave-de-bis.png`

```
Pavê de Bis (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite condensado, leite, gemas, amido, creme de leite. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 03. Pavê de morango (sobremesa)
Arquivo: `pave-de-morango.png`

```
Pavê de morango (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite, leite condensado, amido, creme de leite, biscoito maisena. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 04. Pavê de amendoim (sobremesa)
Arquivo: `pave-de-amendoim.png`

```
Pavê de amendoim (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: amendoim torrado sem pele, leite condensado, creme de leite, leite, amido. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 05. Bombom de uva na travessa (sobremesa)
Arquivo: `bombom-de-uva-na-travessa.png`

```
Bombom de uva na travessa (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: uva sem semente, leite condensado, manteiga, creme de leite, chocolate meio amargo. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 06. Pavê de abacaxi (sobremesa)
Arquivo: `pave-de-abacaxi.png`

```
Pavê de abacaxi (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: abacaxi, açúcar, leite condensado, leite, amido. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 07. Rabanada tradicional (sobremesa)
Arquivo: `rabanada-tradicional.png`

```
Rabanada tradicional (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: pão amanhecido, leite, leite condensado, ovos, açúcar. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 08. Rabanada assada (sobremesa)
Arquivo: `rabanada-assada.png`

```
Rabanada assada (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: pão amanhecido, leite, leite condensado, ovos, manteiga. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 09. Manjar de coco com ameixa (sobremesa)
Arquivo: `manjar-de-coco-com-ameixa.png`

```
Manjar de coco com ameixa (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite, leite de coco, leite condensado, coco ralado, amido. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 10. Pudim de panetone (sobremesa)
Arquivo: `pudim-de-panetone.png`

```
Pudim de panetone (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: panetone, leite, leite condensado, ovos, açúcar. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 11. Pudim de leite condensado (sobremesa)
Arquivo: `pudim-de-leite-condensado.png`

```
Pudim de leite condensado (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite condensado, leite, ovos, açúcar. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 12. Mousse de maracujá (sobremesa)
Arquivo: `mousse-de-maracuja.png`

```
Mousse de maracujá (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite condensado, creme de leite, suco concentrado de maracujá, maracujá (cobertura), açúcar. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 13. Mousse de limão (sobremesa)
Arquivo: `mousse-de-limao.png`

```
Mousse de limão (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite condensado, creme de leite, suco de limão, raspas de, biscoito triturado. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 14. Gelatina mosaico (sobremesa)
Arquivo: `gelatina-mosaico.png`

```
Gelatina mosaico (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: gelatina, água quente, água fria, gelatina incolor, leite condensado. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 15. Bolo gelado de chocolate (sobremesa)
Arquivo: `bolo-gelado-de-chocolate.png`

```
Bolo gelado de chocolate (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: farinha, açúcar, chocolate em pó, ovos, leite. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 16. Chocotone recheado (sobremesa)
Arquivo: `chocotone-recheado.png`

```
Chocotone recheado (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: chocotone, leite condensado, creme de leite, chocolate meio amargo, manteiga. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 17. Pavê de panetone (sobremesa)
Arquivo: `pave-de-panetone.png`

```
Pavê de panetone (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: panetone, leite, leite condensado, amido, creme de leite. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 18. Torta de chocolate com morango (sobremesa)
Arquivo: `torta-de-chocolate-com-morango.png`

```
Torta de chocolate com morango (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: biscoito maisena, manteiga, chocolate meio amargo, creme de leite, morango. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 19. Cheesecake com frutas vermelhas (sobremesa)
Arquivo: `cheesecake-com-frutas-vermelhas.png`

```
Cheesecake com frutas vermelhas (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: biscoito, manteiga, cream cheese, açúcar, ovos. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 20. Salada de frutas cremosa (sobremesa)
Arquivo: `salada-de-frutas-cremosa.png`

```
Salada de frutas cremosa (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: banana, maçã, mamão, manga, uva. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 21. Torta holandesa (sobremesa)
Arquivo: `torta-holandesa.png`

```
Torta holandesa (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: biscoito maisena, manteiga, biscoitos cobertos chocolate, manteiga, açúcar. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## 22. Brigadeirão (sobremesa)
Arquivo: `brigadeirao.png`

```
Brigadeirão (Brazilian Christmas dish), in a glass dish, one portion served on a small plate, visible ingredients: leite condensado, creme de leite, chocolate em pó, ovos, manteiga. Realistic professional food photography, Brazilian Christmas dinner, served in a cream ceramic dish on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

---

# Bebidas

Obs.: refrigerantes aparecem com latas genéricas; logotipos de marcas não devem ser gerados por IA.

## B01. espumante
Arquivo: `espumante.png`

```
Sparkling wine being poured into two crystal flutes, unlabeled green bottle. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B02. vinho-tinto-seco
Arquivo: `vinho-tinto-seco.png`

```
Red wine in a wine glass next to an unlabeled dark bottle. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B03. vinho-tinto-suave
Arquivo: `vinho-tinto-suave.png`

```
Red wine in a wine glass next to an unlabeled bottle. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B04. vinho-branco-seco
Arquivo: `vinho-branco-seco.png`

```
White wine in a wine glass next to an unlabeled bottle. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B05. vinho-branco-suave
Arquivo: `vinho-branco-suave.png`

```
Pale white wine in a wine glass next to an unlabeled bottle. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B06. vinho-rose
Arquivo: `vinho-rose.png`

```
Rosé wine in a wine glass next to an unlabeled bottle. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B07. caipirinha
Arquivo: `caipirinha.png`

```
Brazilian caipirinha in a short glass, crushed lime and ice. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B08. caipiroska
Arquivo: `caipiroska.png`

```
Caipiroska in a short glass with crushed lime and ice. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B09. suco-laranja
Arquivo: `suco-laranja.png`

```
Fresh orange juice in a glass pitcher and glass, oranges beside. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B10. suco-abacaxi
Arquivo: `suco-abacaxi.png`

```
Fresh pineapple juice in a glass pitcher and glass, pineapple beside. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B11. suco-maracuja
Arquivo: `suco-maracuja.png`

```
Passion fruit juice in a glass pitcher and glass, halved passion fruits beside. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B12. suco-melancia
Arquivo: `suco-melancia.png`

```
Watermelon juice in a glass pitcher and glass, watermelon slice beside. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B13. limonada
Arquivo: `limonada.png`

```
Lemonade in a glass pitcher with lime slices and ice. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B14. suco-abacaxi-hortela
Arquivo: `suco-abacaxi-hortela.png`

```
Pineapple and mint juice in a glass with mint leaves. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B15. coca-cola
Arquivo: `coca-cola.png`

```
Glass of cola with ice, generic unbranded red can. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B16. guarana
Arquivo: `guarana.png`

```
Glass of Brazilian guaraná soda with ice, generic unbranded green can. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B17. sprite
Arquivo: `sprite.png`

```
Glass of lemon-lime soda with ice, generic unbranded can. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B18. fanta
Arquivo: `fanta.png`

```
Glass of orange soda with ice, generic unbranded can. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B19. agua-com-gas
Arquivo: `agua-com-gas.png`

```
Sparkling water in a glass with bubbles, unlabeled bottle. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```

## B20. agua-com-limao
Arquivo: `agua-com-limao.png`

```
Water with lime slices and ice in a glass pitcher. Realistic professional food photography, Brazilian Christmas dinner, drink styled on a rustic wooden table, subtle Christmas details (pine sprigs, small gold ornaments), soft natural side light, dark green blurred background, 45-degree angle, shallow depth of field, appetizing, home-cooked look, 4:3 aspect ratio, no text, no people, no hands, no logos, no brand labels
```
