# ceia.fácil — prompts de fotos no estilo que você escolheu

Como usar: cole o prompt no ChatGPT ou no Gemini, pedindo **formato 4:3**. Salve na pasta **FOTOS CEIA** com o nome indicado. Se quiser, anexe a foto de referência e escreva antes: "Crie uma foto ORIGINAL inspirada no clima desta imagem, sem copiá-la".

Final igual em todos (já incluído): *photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands*

---

## Salgados

**Arroz à grega**: `Arroz à grega.webp`
```
Brazilian Christmas rice with diced carrots, red pepper, peas and raisins in a dark rustic wooden bowl, garnished with a parsley sprig, on a festive table with red and gold Christmas baubles, candles and warm bokeh lights, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Arroz com brócolis**: `Arroz com brócolis.webp`
```
Fluffy white rice mixed with bright green broccoli florets inside a red enameled cast-iron pot, close-up from a 45-degree angle, light neutral background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Bacalhau ao forno**: `Bacalhau ao forno.webp`
```
Oven-baked Portuguese-style salt cod fillets layered with potato slices, onion rings, red, yellow and green bell pepper strips and green olives, chopped parsley on top, in an oval white ceramic baking dish, Christmas table with candles and pine in the background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Batata gratinada**: `Batata gratinada.webp`
```
Creamy potato gratin with golden browned cheese crust and rosemary sprigs in a rectangular beige ceramic baking dish, linen napkin underneath, light grey background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Bruschetta de tomate**: `Bruschetta de tomate.webp`
```
Toasted bread slices topped with diced tomatoes, fresh basil and a drizzle of balsamic on a round wooden platter, small bowl of olive oil and garlic cloves beside it, linen tablecloth, window light, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Caponata de berinjela**: `Caponata de berinjela.webp`
```
Eggplant caponata with tomatoes, peppers, celery and green olives in a terracotta bowl, toasted bread slices and a glass bottle of olive oil beside it, rustic wooden table, top-down 45-degree view, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Carne assada ao molho madeira**: `Carne assada ao molho madeira.webp`
```
Sliced roast beef covered in glossy brown madeira sauce with sliced mushrooms on a white rectangular serving tray, bowls of mashed potatoes and white rice around it, red napkins, warm dinner table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Costela bovina assada**: `Costela bovina assada.webp`
```
Slow-roasted beef short rib with dark caramelized crust and exposed bones resting on a rustic wooden board, juices on the board, close-up, warm moody light, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Costela suína assada**: `Costela suína assada.webp`
```
Top-down view of a glazed roasted pork rib rack sprinkled with dried herbs on a wooden cutting board, warm wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Cuscuz paulista**: `Cuscuz paulista.webp`
```
Brazilian cuscuz paulista unmolded in a ring shape, decorated with hard-boiled egg slices, red and yellow pepper strips, green peas, sliced olives and sardines, on a white plate, cherry tomatoes on a wooden slab in the background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Empadão de frango**: `Empadão de frango.webp`
```
Tall Brazilian chicken pot pie with golden braided lattice crust, one slice being lifted on a cake server showing creamy shredded chicken filling, white plate, rustic wood, striped kitchen towel, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Farofa de bacon e cebola**: `Farofa de bacon e cebola.webp`
```
Golden toasted cassava flour farofa with crispy bacon cubes, caramelized onion and parsley in a dark grey oval dish with a spoon, eggs and a slab of bacon blurred in the background, dark wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Farofa de banana**: `Farofa de banana.webp`
```
Cassava flour farofa with golden sautéed banana slices, onion and parsley in a beige ceramic bowl, a lime wedge on the side, wooden spoons and linen cloth, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Farofa de calabresa com ovos**: `Farofa de calabresa com ovos.webp`
```
Farofa with browned smoked sausage slices, scrambled egg pieces and parsley in a black skillet, red checkered cloth, rustic wood, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Farofa natalina com frutas secas**: `Farofa natalina com frutas secas.webp`
```
Christmas farofa with prunes, dried apricots, raisins and chopped nuts in a cast-iron pan, red and white checkered cloth, red Christmas baubles and pine branches, rustic wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Frango assado com batatas**: `Frango assado com batatas.webp`
```
Whole golden roast chicken surrounded by roasted potato wedges sprinkled with chives on a round platter, teal placemat, light background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Maionese de batata**: `Maionese de batata.webp`
```
Creamy Brazilian potato salad with mayonnaise and chopped chives in a grey ceramic bowl, blue napkin, cherry tomatoes blurred behind, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Patê de atum**: `Patê de atum.webp`
```
Creamy tuna pâté in a white bowl garnished with parsley, slices of rustic bread with pâté spread on them, an open tuna can without label, lemon half and parsley on a wooden board, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Peixe assado com ervas e limão**: `Peixe assado com ervas e limão.webp`
```
Golden roasted white fish with crispy herb-and-pepper crust in a light lemon butter sauce, lime halves and rosemary on a white platter, close-up, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pernil suíno assado**: `Pernil suíno assado.webp`
```
Roasted pork leg with crispy seasoned skin in a metal roasting pan with orange slices, whole garlic cloves, onions and rosemary, bowls of rice and farofa around it, rustic table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Quiche de alho-poró**: `Quiche de alho-poró.webp`
```
Leek quiche in a fluted golden pastry crust with one slice cut out and placed beside it, ceramic plate on a wooden table, green salad and a glass of white wine in the background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Salada de grão-de-bico**: `Salada de grão-de-bico.webp`
```
Chickpea salad with diced cucumber, tomato, red bell pepper and red onion with parsley in a teal ceramic bowl, piece of flatbread on the side, dark slate and wood, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Salada tropical**: `Salada tropical.webp`
```
Tropical salad with lettuce, arugula, mango and pineapple cubes, cherry tomatoes, grated carrot and chopped cashew nuts in a glass bowl, dressing in a small cup, orange and lemon halves, dark wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Tender natalino com abacaxi**: `Tender natalino com abacaxi.webp`
```
Glazed Christmas ham with scored diamond crust, caramelized pineapple rings and red cherries on top, partly sliced showing pink interior, white plate with glaze sauce, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Torta fria de frango**: `Torta fria de frango.webp`
```
Brazilian layered sandwich cake with chicken salad filling, covered with mayonnaise and topped with crispy shoestring potatoes, one wedge cut showing white bread and colorful filling layers, white plate, parsley and cherry tomatoes, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

## Sobremesas

**Bolo gelado de chocolate**: `Bolo gelado de chocolate.webp`
```
Square piece of Brazilian iced chocolate cake covered in chocolate sprinkles, unwrapped on aluminum foil, other foil-wrapped pieces stacked behind, wooden board, dried flowers, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Bombom de uva na travessa**: `Bombom de uva na travessa.webp`
```
Layered dessert in a glass baking dish: green seedless grapes, white condensed milk cream and glossy chocolate ganache with chocolate shavings, one portion lifted on a serving spoon, green grapes in the background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Brigadeirão**: `Brigadeirão.webp`
```
Large ring-shaped Brazilian chocolate flan (brigadeirão) covered in chocolate sprinkles on a white plate, sprinkles scattered around, small bowls of cocoa powder and chocolate pieces behind, light neutral table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Cheesecake com frutas vermelhas**: `Cheesecake com frutas vermelhas.webp`
```
Round cheesecake with biscuit base topped with glossy red berry sauce, fresh strawberries and raspberries, on a white scalloped plate, rustic wood and yellow napkin, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Chocotone recheado**: `Chocotone recheado.webp`
```
Chocolate chip panettone cut in half and filled with creamy chocolate brigadeiro, stacked on a dark plate, Christmas golden decorations in the background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Manjar de coco com ameixa**: `Manjar de coco com ameixa.webp`
```
White coconut pudding ring topped with prunes and amber prune syrup on a green plate, one slice served in front with syrup, wooden board, dark countertop, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Mousse de limão**: `Mousse de limão.webp`
```
Lime mousse in a round glass bowl sprinkled with lime zest, a spoonful being scooped, lime halves and a wooden juicer beside it, light blue wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Mousse de maracujá**: `Mousse de maracujá.webp`
```
Passion fruit mousse topped with glossy passion fruit pulp and seeds in a lilac ceramic baking dish, a spoonful lifted, purple napkin and whole passion fruits behind, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pavê de abacaxi**: `Pavê de abacaxi.webp`
```
Pineapple trifle in a round glass dish: layers of white cream and biscuits topped with cooked pineapple pieces and white chocolate curls, whole pineapple behind, green gingham tablecloth, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pavê de amendoim**: `Pavê de amendoim.webp`
```
Peanut trifle in a rectangular glass dish covered with chopped toasted peanuts, one square slice lifted on a spatula showing cream and biscuit layers, mint leaf garnish, warm orange background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pavê de Bis**: `Pavê de Bis.webp`
```
Round glass dish of layered white cream and chocolate trifle with smooth milk chocolate ganache top, chopped chocolate wafer bars around the edge, small decorative Christmas tree beside it, white kitchen counter, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pavê de chocolate**: `Pavê de chocolate.webp`
```
Oval glass dish of chocolate trifle with visible layers of chocolate cream, vanilla cream and ladyfinger biscuits, top covered with chocolate shavings, on an ornate golden tray with a golden spoon, red berries, pine and candles, champagne glasses, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pavê de morango**: `Pavê de morango.webp`
```
Strawberry trifle in an oval glass dish with layers of biscuits, vanilla cream and strawberry halves, fresh strawberries on top, one portion removed showing the layers, lace doily and orange tablecloth, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pavê de panetone**: `Pavê de panetone.webp`
```
Panettone trifle in a clear glass bowl with layers of panettone pieces, vanilla cream and chocolate ganache, topped with chocolate shavings, white towel with red stripes, soft Christmas lights in the background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pudim de leite condensado**: `Pudim de leite condensado.webp`
```
Classic Brazilian condensed milk flan ring with glossy amber caramel on a round white plate, dark rustic wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Pudim de panetone**: `Pudim de panetone.webp`
```
Panettone bread pudding ring with caramel top and candied fruit pieces, one slice cut and lifted on a cake server, raisins on the plate, light grey background, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Rabanada assada**: `Rabanada assada.webp`
```
Oven-baked Brazilian French toast slices coated in cinnamon sugar in a glass baking dish, red plaid napkin and colorful Christmas lights blurred behind, rustic wood, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Rabanada tradicional**: `Rabanada tradicional.webp`
```
Stack of fried Brazilian rabanadas coated in cinnamon sugar on a red plate, bowl of eggs and Christmas ornaments in the background, wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Torta de chocolate com morango**: `Torta de chocolate com morango.webp`
```
Round chocolate tart with biscuit crust, shiny chocolate ganache top, halved strawberries and chocolate sprinkles around the edge, one slice cut, wooden table, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

**Torta holandesa**: `Torta holandesa.webp`
```
Dutch-style cream pie with biscuit crust, thick white butter cream filling and glossy chocolate ganache top, chocolate-covered round biscuits standing around the side, one slice cut, white plate, coffee cups and lace tablecloth, photorealistic food photography, natural soft light, shallow depth of field, appetizing, 4:3, no text, no logos, no watermarks, no people, no hands
```

---

## Pratos sem foto de referência (use os prompts do primeiro arquivo)

Arroz natalino com castanhas · Bolinho de bacalhau · Chester assado · Frango recheado com farofa · Gelatina mosaico · Legumes assados · Lombo suíno ao molho de laranja · Pão recheado com queijo e ervas · Peru assado tradicional · Purê de mandioquinha · Salada de frutas cremosa · Salpicão de frango · Vinagrete tradicional
