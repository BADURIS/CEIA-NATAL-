// Webhook de pagamento — camada independente do provedor (checkout ainda não escolhido).
// Regras: valida assinatura no servidor, grava o evento uma única vez (idempotência)
// e só libera acesso com pagamento confirmado. Retorno do checkout no navegador nunca libera nada.
import { createClient } from "jsr:@supabase/supabase-js@2";

type Normalized = {
  provider: string;
  eventId: string;
  type: "approved" | "refunded" | "chargeback" | "canceled" | "other";
  email: string | null;
  productId: string | null;
};

/**
 * Adaptadores por provedor. Ao escolher o checkout, implemente o dele aqui
 * (Kiwify, Hotmart, Mercado Pago, Stripe...) mapeando para o formato Normalized.
 */
const adapters: Record<string, (body: Record<string, unknown>) => Normalized> = {
  // Formato genérico, usado em testes e como modelo.
  generic: (b) => ({
    provider: "generic",
    eventId: String(b.id ?? ""),
    type: (["approved", "refunded", "chargeback", "canceled"].includes(String(b.type)) ? b.type : "other") as Normalized["type"],
    email: typeof b.email === "string" ? b.email.trim().toLowerCase() : null,
    productId: typeof b.product_id === "string" ? b.product_id : null,
  }),
};

async function validSignature(raw: string, signature: string | null, secret: string): Promise<boolean> {
  if (!signature) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw)));
  const expected = Array.from(mac, (x) => x.toString(16).padStart(2, "0")).join("");
  // comparação em tempo constante
  if (expected.length !== signature.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ signature.charCodeAt(i);
  return diff === 0;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });

  const provider = new URL(req.url).searchParams.get("provider") ?? "generic";
  const adapter = adapters[provider];
  if (!adapter) return new Response("unknown provider", { status: 400 });

  const raw = await req.text();
  const secret = Deno.env.get("WEBHOOK_SECRET");
  if (!secret || !(await validSignature(raw, req.headers.get("x-webhook-signature"), secret)))
    return new Response("invalid signature", { status: 401 });

  let body: Record<string, unknown>;
  try {
    body = JSON.parse(raw);
  } catch {
    return new Response("invalid json", { status: 400 });
  }
  const ev = adapter(body);
  if (!ev.eventId) return new Response("missing event id", { status: 400 });

  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

  // Idempotência: o mesmo evento reenviado não é processado duas vezes.
  const { data: inserted, error } = await db
    .from("payment_events")
    .upsert({ provider: ev.provider, provider_event_id: ev.eventId, event_type: ev.type, email: ev.email, product_id: ev.productId, payload: body }, { onConflict: "provider,provider_event_id", ignoreDuplicates: true })
    .select("id")
    .maybeSingle();
  if (error) return new Response("db error", { status: 500 });
  if (!inserted) return new Response("duplicate", { status: 200 });

  if (ev.email && ev.productId) {
    const { data: product } = await db.from("products").select("id").eq("id", ev.productId).eq("active", true).maybeSingle();
    if (product) {
      if (ev.type === "approved") {
        await db.from("entitlements").upsert(
          { email: ev.email, product_id: ev.productId, status: "active", source_event_id: inserted.id, updated_at: new Date().toISOString() },
          { onConflict: "email,product_id" },
        );
      } else if (ev.type === "refunded" || ev.type === "chargeback") {
        await db.from("entitlements").update({ status: "revoked", source_event_id: inserted.id, updated_at: new Date().toISOString() })
          .eq("email", ev.email).eq("product_id", ev.productId);
      }
    }
  }
  await db.from("payment_events").update({ processed_at: new Date().toISOString() }).eq("id", inserted.id);
  return new Response("ok", { status: 200 });
});
